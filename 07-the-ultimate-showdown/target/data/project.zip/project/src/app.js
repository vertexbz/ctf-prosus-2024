const express = require("express");
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use("/user", require("./controllers/user.js"));
app.use("/admin". require("./controllers/adminjs"))

global.db_user = require("./database/userDB.js")
global.db_admin = require("./database/adminDB.js")

app.get("*", (req, res) => {

	res.status(404).json({"reason": "Sorry not found!})
})
