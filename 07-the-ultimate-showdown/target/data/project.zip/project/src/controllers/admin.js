const app = express.router()

app.get('/admin/:id', (req, res, next) => {
  // if the admin ID is 0, skip to the next route
  if (req.params.id === '0') next('route')
  // otherwise pass the control to the next middleware function in this stack
  else next()
}, (req, res, next) => {
  // send a regular response
  res.send('regular')
})

// handler for the /admin/:id path, which sends a special response
app.get('/admin/:id', (req, res, next) => {
  res.send('special')
})

